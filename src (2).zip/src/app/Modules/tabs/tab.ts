export interface Tab {
  title: string;
  active: boolean;
  iconClass: string;
  content: string;
};
