export interface Cat4 {
    CategoryId: number;
    ParentCategory:string;
    ChildCategory:string;
    GroupCategory:string;
    IsActive:boolean;
}
