export interface MSTUsersDto {
    Id: number;
    IsActive: boolean;
    Created_by: number;
    RoleId: number;
    ModifiedBy: number;
    BUIDs: any;
}
