export interface pagevisitlogs {
    Id?: number,
    UserId?: string,
    SessionId?: string,
    Page?:string,
    EntryTime?: Date,
    ExitTime?: Date,
    Duration?: number,
    CreatedOn?: Date,
}

