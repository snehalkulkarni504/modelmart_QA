export interface Authclass {
    Token: any,
    RefreshToken: any,
    RefreshTokenExpires: any,
}
