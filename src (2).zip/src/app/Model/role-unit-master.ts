export interface RoleUnitMaster {
    id: number,
    roleName: string,
    menu :any,
    description: string,
    status:string,
    createdBy: string,
    createdDate: Date
}
