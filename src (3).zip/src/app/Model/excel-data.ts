export interface ExcelData {
        // ProjectType?: string,
        // BusinessUnit?:string,
        // ProgramName?:string,
        // SuppManuLoc?:string,
        // PartName?:string,
        // PartNumber?:string,
       // ProjectName?:string,
        UniqueID? :string
}
