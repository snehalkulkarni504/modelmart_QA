export interface CategoryMaster {
}
