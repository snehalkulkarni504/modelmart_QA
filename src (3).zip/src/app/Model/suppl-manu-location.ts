export interface SupplManuLocation {
    LocationId: number,
    LocationName: string,
    Currency: string,
    Status:string,
    CreatedBy: string,
    CreatedOn: Date,
    ModifiedBy: string,
    ModifiedOn: Date
}
