import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MSAL_GUARD_CONFIG, MsalBroadcastService, MsalGuardConfiguration, MsalService } from '@azure/msal-angular';
import { AuthenticationResult, EventMessage, EventType, InteractionStatus, PopupRequest, RedirectRequest } from '@azure/msal-browser';
import { Subject, filter, takeUntil } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Model Mart';

  constructor(public router: Router,
    @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
    private msalService: MsalService,
    private msalBroadcastService: MsalBroadcastService) {
    this.IsLogin = false;

  }

  // myScriptElement: HTMLScriptElement;

  // constructor(public router: Router,
  //   @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration,
  //   private msalService: MsalService,
  //   private msalBroadcastService: MsalBroadcastService
  // ) {
  //   this.myScriptElement = document.createElement("script");
  //   this.myScriptElement.src = "assets/slider.js";
  //   document.body.appendChild(this.myScriptElement);
  // }

  IsloginDisplay = false;
  IsLogin: boolean = false;

  ngOnInit() {
   // debugger;

    // if (this.IsloginDisplay) {
    //   this.router.navigate(['/home/search/ ']);
    // }

    // this.msalBroadcastService.inProgress$
    //   .pipe(
    //     filter((status: InteractionStatus) => status === InteractionStatus.None))
    //   .subscribe(() => {
    //     debugger;
    //     console.log(this.msalService.instance.getAllAccounts()[0])
    //     this.IsloginDisplay = this.msalService.instance.getAllAccounts().length > 0;
    //     this.router.navigate(['/home/search/ ']);

    //     var Username = this.msalService.instance.getAllAccounts()[0].username.split("@")[0];
    //     localStorage.setItem("userName", Username);
    //     console.log("Username APP ", Username);

    //     // if (this.IsloginDisplay) {
    //     //   this.router.navigate(['/home/search/ ']);
    //     // }
    //     // else {
    //     //   this.router.navigate(['/welcome']);
    //     // }

    //   });

    // this.msalBroadcastService.msalSubject$
    //   .pipe(filter((msg: EventMessage) => msg.eventType === EventType.LOGIN_SUCCESS || msg.eventType === EventType.SSO_SILENT_SUCCESS))
    //   .subscribe(async (result: EventMessage) => {

    //   });


    // setInterval(() => {
    //   if (this.msalService.instance.getAllAccounts().length > 0) {
    //    // console.log(this.msalService.instance.getAllAccounts());
    //     if (this.msalService.instance.getAllAccounts()[0].username.length > 0) {
    //       var Username = this.msalService.instance.getAllAccounts()[0].username.split("@")[0];
    //       localStorage.setItem("userName", Username);
    //       // console.log("Username app ", Username)
    //       // console.log("Username app localStorage", localStorage.getItem("userName"));
    //       if (this.IsLogin != true) {
    //         this.IsLogin = true;
    //         //this.router.navigate(['/home']);  
    //         this.router.navigate(['/home/search/ ']);
    //       }
    //     }
    //   }
    // }, 100);

    // this.router.navigate(['/home/search/ ']);


    // this.msalBroadcastService.inProgress$
    //   .pipe(
    //     filter((status: InteractionStatus) => status === InteractionStatus.None))
    //   .subscribe(() => {
    //     this.IsloginDisplay = this.msalService.instance.getAllAccounts().length > 0;
    //   })

    // if (this.msalService.instance.getAllAccounts().length > 0) {
    //   console.log(this.msalService.instance.getAllAccounts());
    // }

    // console.log(this.IsloginDisplay);
    // console.log(this.msalService.instance.getAllAccounts());

    // setInterval(() => {
    //   if (this.msalService.instance.getAllAccounts().length > 0) {
    //     if (this.msalService.instance.getAllAccounts()[0].username.length > 0) {
    //       var Username = this.msalService.instance.getAllAccounts()[0].username.split("@")[0];
    //       localStorage.setItem("userName", Username);
    //       if (this.IsLogin != true) {
    //         this.IsLogin = true;
    //         //this.router.navigate(['/home']);  
    //         this.router.navigate(['/home/search/ ']);
    //       }
    //     }
    //   }
    // }, 500);

  }

  // logIn() {
  //   debugger;
  //   if (this.msalService.instance.getAllAccounts()[0].username.length > 0) {
  //     var Username = this.msalService.instance.getAllAccounts()[0].username.split("@")[0];
  //     localStorage.setItem("userName", Username);
  //     //this.router.navigate(['/home']);  
  //     this.router.navigate(['/home/search/ ']);
  //   }
  // }


  // GotoLogin() {
  //   this.IsloginDisplay = true;
  //   this.router.navigate(['/login']);
  // }


  // loginRedirect() {
  //   debugger;
  //   if (this.msalGuardConfig.authRequest) {
  //     this.msalService.loginRedirect({ ...this.msalGuardConfig.authRequest } as RedirectRequest);
  //   } else {
  //     this.msalService.loginRedirect();
  //   }
  //   this.router.navigate(['/home/search/ ']);


    // this.router.navigate(['/home/search/ ']);
    // this.msalService.loginPopup().subscribe((response: AuthenticationResult) => {
    //   if (response != null) {
    //     debugger;
    //     var emailID = response.account?.username!;
    //     var UserNm =  this.msalService.instance.getAllAccounts()[0].username.split("@")[0];
    //     sessionStorage.setItem('User', UserNm);
    //     this.router.navigate(['/home/search/ ']);
    //     this.msalService.instance.setActiveAccount(response.account)
    //   }
    // });

 // }


  // if (this.msalService.instance.getAllAccounts().length > 0) {
  //   // console.log(this.msalService.instance.getAllAccounts());
  //   if (this.msalService.instance.getAllAccounts()[0].username.length > 0) {
  //     var Username = this.msalService.instance.getAllAccounts()[0].username.split("@")[0];
  //     localStorage.setItem("userName", Username);
  //     // console.log("Username app ", Username)
  //     // console.log("Username app localStorage", localStorage.getItem("userName"));
  //     if (this.IsLogin != true) {
  //       this.IsLogin = true;
  //       //this.router.navigate(['/home']);  
  //       this.router.navigate(['/home/search/ ']);
  //     }
  //   }
  // }


  // setInterval(() => {
  //   debugger;
  //   if (this.msalService.instance.getAllAccounts().length > 0) {
  //    // console.log(this.msalService.instance.getAllAccounts());
  //     if (this.msalService.instance.getAllAccounts()[0].username.length > 0) {
  //       var Username = this.msalService.instance.getAllAccounts()[0].username.split("@")[0];
  //       localStorage.setItem("userName", Username);
  //       // console.log("Username app ", Username)
  //       // console.log("Username app localStorage", localStorage.getItem("userName"));
  //       if (this.IsLogin != true) {
  //         this.IsLogin = true;
  //         //this.router.navigate(['/home']);  
  //         this.router.navigate(['/home/search/ ']);
  //       }
  //     }
  //   }
  // }, 100);

  //SetLoginDisplay() {
    //   debugger;
    //   console.log(this.msalService.instance.getAllAccounts()[0])
    //   this.IsloginDisplay = this.msalService.instance.getAllAccounts().length > 0;
    //   this.router.navigate(['/home/search/ ']);
  //}



}
