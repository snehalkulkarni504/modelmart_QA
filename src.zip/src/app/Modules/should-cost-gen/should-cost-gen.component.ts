import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { SearchService } from 'src/app/SharedServices/search.service';
import { environment } from 'src/environments/environments';
import { Location } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-should-cost-gen',
  templateUrl: './should-cost-gen.component.html',
  styleUrls: ['./should-cost-gen.component.css']
})
export class ShouldCostGenComponent implements OnInit {
  imgName: any;

  //private datePipe: DatePipe
  constructor(public searchservice: SearchService,
    public router: Router, private route: ActivatedRoute, private location: Location, private SpinnerService: NgxSpinnerService, public toastr: ToastrService) {
    // window.scrollTo(0, 0);
    // this.route.params.subscribe(param => {
    //   this.ComapredId = param['ComapredId'];
    // });
  }

  ComapredId: any;
  ShouldeCostData: any = [];
  shouldCostBreakdownList: any = [];
  shouldCostBreakdownNonList: any = [];

  shouldCostBreakdownListT2: any = [];
  shouldCostBreakdownNonListT2: any = [];

  ManufacturingProcess: any = [];
  MaterialGrade: any = [];
  MaterialGradeT2: any = [];

  TotalInUSD: number = 0;
  TotalInLocal: number = 0;
  TotalInPer: number = 0;

  Manu_TotalInUSD: number = 0
  Manu_TotalInLocal: number = 0
  Manu_TotalInPer: number = 0

  Non_TotalInUSD: number = 0
  Non_TotalInLocal: number = 0
  Non_TotalInPer: number = 0

  TotalInUSDT2: number = 0;
  TotalInLocalT2: number = 0;
  TotalInPerT2: number = 0;

  Manu_TotalInUSDT2: number = 0
  Manu_TotalInLocalT2: number = 0
  Manu_TotalInPerT2: number = 0

  Non_TotalInUSDT2: number = 0
  Non_TotalInLocalT2: number = 0
  Non_TotalInPerT2: number = 0

  ProjectDetails!: FormGroup; ShouldCostBreakdown!: FormGroup; PartDimensionDetails!: FormGroup;
  ProjectName: any; CategoryCAT4: any; EstimatedSpend: any; BusinessUnit: any; CategoryCAT2: any; CategoryCAT3: any;
  PartNumber: any; Projecttype: any; SupplierName: any; Location: any; TargetQuote: any; Costtype: any; DebriefDate: any;
  PartName: any; IncoTerms: any; Forex: any; BatchSize: any; ForexRegion: any; DebriefDateFormated: any; UniqueId: any;
  ToolingCost: any;
  AnnualVolume: any;
  RoleId: any;
  fvOnly: any;
  ShouldCostModeller: any; ToolingCostModeller: any;
  PartLength: any; PartWidth: any; PartHeight: any; PartVolume: any; PartWeight: any; PartWeight_in_Pounds: any;
  imgsilderData: any;
  mainimg: any // =  "img/test_1.jpeg";
  mainimgzoom: any;
  userId: any;
  NA: any = "NA*";
  IsHiddenT2: boolean = false;
  AluminiumCastingGrade: any;


  ngOnInit(): void {

    this.router.events.subscribe((event) => {
      window.scrollTo(0, 0)
    });

    //debugger;;
    if (localStorage.getItem("userName") == null) {
      this.router.navigate(['/welcome']);
      return;
    }

    this.userId = localStorage.getItem("userId");

    this.ComapredId = localStorage.getItem("ComapredId");
    // this.mainimg = localStorage.getItem("imagePath");
    // if (this.mainimg == "") {
    //   this.mainimg = 'assets/No-Image.png';
    // }

    this.ProjectDetails = new FormGroup({
      ProjectName: new FormControl(), CategoryCAT4: new FormControl(), EstimatedSpend: new FormControl(),
      BusinessUnit: new FormControl(), CategoryCAT2: new FormControl(), CategoryCAT3: new FormControl(),
      PartNumber: new FormControl(), Projecttype: new FormControl(), SupplierName: new FormControl(),
      Location: new FormControl(), TargetQuote: new FormControl(), Costtype: new FormControl(), PartName: new FormControl(),
      DebriefDate: new FormControl(), IncoTerms: new FormControl(), Forex: new FormControl(), BatchSize: new FormControl(),
      AnnualVolume: new FormControl()
    });

    this.PartDimensionDetails = new FormGroup({
      ShouldCostModeller: new FormControl(), ToolingCostModeller: new FormControl(),
      PartLength: new FormControl(), PartWidth: new FormControl(), PartHeight: new FormControl(), PartVolume: new FormControl(),
      PartWeight: new FormControl(),
    });
    console.log("ComapredId : " + this.ComapredId);
    this.getShouldeCost(this.ComapredId);

  }


  hasData(): boolean {
    return this.MaterialGrade.length > 0;
  }

  hasDataT2(): boolean {
    return this.MaterialGradeT2.length > 0;
  }

  async getShouldeCost(id: number) {
    try {
      this.SpinnerService.show('spinner');

      const data = await this.searchservice.getShouldeCost(id, this.userId).toPromise();
      //this.ShouldeCostData = data;

      this.BatchSize = data.projectDetails[0].batchSize;
      this.BusinessUnit = data.projectDetails[0].businessUnit;
      this.CategoryCAT2 = data.projectDetails[0].caT2;
      this.CategoryCAT3 = data.projectDetails[0].caT3;
      this.CategoryCAT4 = data.projectDetails[0].caT4;
      this.DebriefDate = data.projectDetails[0].debriefDate;
      this.DebriefDateFormated = data.projectDetails[0].debriefDateFormated;
      this.EstimatedSpend = data.projectDetails[0].estimatedSpend;
      this.Forex = data.projectDetails[0].forex;
      this.Location = data.projectDetails[0].mfgRegion;
      this.PartNumber = data.projectDetails[0].partNumber;
      this.PartName = data.projectDetails[0].partName;
      this.ProjectName = data.projectDetails[0].projectName;
      this.Projecttype = data.projectDetails[0].projectType;
      this.SupplierName = data.projectDetails[0].supplier;
      this.TargetQuote = data.projectDetails[0].targetQuote;
      this.ForexRegion = data.projectDetails[0].forexRegion;
      this.Costtype = data.projectDetails[0].costType;
      this.AnnualVolume = data.projectDetails[0].annualVolume;
      this.RoleId = data.projectDetails[0].roleId;
      this.UniqueId = data.projectDetails[0].uniqueId;

      if (data.projectDetails[0].toolingCost == undefined || data.projectDetails[0].toolingCost == null) {
        this.ToolingCost = this.NA;
      }
      else {

        this.ToolingCost = data.projectDetails[0].toolingCost.toFixed(2);
      }

      this.ShouldCostModeller = data.partDimensionDetails[0].shouldCostModeller;
      this.ToolingCostModeller = data.partDimensionDetails[0].toolingCostModeller;

      if (data.partDimensionDetails[0].length == undefined || data.partDimensionDetails[0].length == null) {
        this.PartLength = this.NA;
      }
      else {
        this.PartLength = data.partDimensionDetails[0].length.toFixed(2);
      }

      if (data.partDimensionDetails[0].width == undefined || data.partDimensionDetails[0].width == null) {
        this.PartWidth = this.NA;
      }
      else {
        this.PartWidth = data.partDimensionDetails[0].width.toFixed(2);
      }

      if (data.partDimensionDetails[0].height == undefined || data.partDimensionDetails[0].height == null) {
        this.PartHeight = this.NA;
      }
      else {
        this.PartHeight = data.partDimensionDetails[0].height.toFixed(2);
      }


      this.PartVolume = data.partDimensionDetails[0].volume;

      if (data.partDimensionDetails[0].finishWeight == undefined || data.partDimensionDetails[0].finishWeight == null) {
        this.PartWeight = this.NA;
        this.PartWeight_in_Pounds = this.NA;
      }
      else {
        this.PartWeight = data.partDimensionDetails[0].finishWeight.toFixed(2);
        this.PartWeight_in_Pounds = (parseFloat(this.PartWeight) * 2.20462).toFixed(2);
      }

      //debugger;;

      this.shouldCostBreakdownList = [];
      this.shouldCostBreakdownNonList = [];
      this.shouldCostBreakdownListT2 = [];
      this.shouldCostBreakdownNonListT2 = [];

      this.shouldCostBreakdownList = data.shouldCostBreakdown;
      this.shouldCostBreakdownNonList = data.shouldCostBreakdownNon;


      this.shouldCostBreakdownListT2 = data.shouldCostBreakdownT2;
      this.shouldCostBreakdownNonListT2 = data.shouldCostBreakdownNonT2;

      let totalCostT2 = 0;
      for (var i = 0; i < this.shouldCostBreakdownListT2.length; i++) {
        totalCostT2 += this.shouldCostBreakdownListT2[i].usdValue;
      }


      // if (this.shouldCostBreakdownListT2[0].usdValue <= 0) {
      //   this.IsHiddenT2 = true;
      // }
      // else {
      //   this.IsHiddenT2 = false;
      // }

      if (totalCostT2 > 0) {
        this.IsHiddenT2 = false;
      }
      else {
        this.IsHiddenT2 = true;
      }

      this.ManufacturingProcess = data.manufacturingProcess;

      //debugger;;
      this.MaterialGrade = data.materialGradeDetails;
      this.AluminiumCastingGrade = [];
      this.AluminiumCastingGrade = data.aluminiumCastingGradeRe;
      //console.log(this.AluminiumCastingGrade);

      for (var i = 0; i < this.MaterialGrade.length; i++) {
        for (var j = 0; j < this.AluminiumCastingGrade.length; j++) {
          var rr = this.AluminiumCastingGrade[j].materialName.toLowerCase();
          if (this.MaterialGrade[i].materialType.toLowerCase().includes(rr)) {
            // G6/((1+5%)*100%-((1-D6)*(0.9)))
            var Utilization = (this.MaterialGrade[i].partFinishWeight / this.MaterialGrade[i].partGrossWeight).toFixed(2);
            this.MaterialGrade[i].directMaterialRate = parseFloat(this.MaterialGrade[i].directMaterialRate) / ((1 + 0.05) * 1 - ((1 - parseFloat(Utilization)) * (0.9)));

            if (isNaN(this.MaterialGrade[i].directMaterialRate)) {
              this.MaterialGrade[i].directMaterialRate = null;
            }
            break;
          }

        }
      }

      this.MaterialGradeT2 = data.materialGradeDetailsT2;


      for (var i = 0; i < this.MaterialGradeT2.length; i++) {
        for (var j = 0; j < this.AluminiumCastingGrade.length; j++) {
          var rr = this.AluminiumCastingGrade[j].materialName.toLowerCase();
          if (this.MaterialGradeT2[i].materialType.toLowerCase().includes(rr)) {
            // G6/((1+5%)*100%-((1-D6)*(0.9)))
            var Utilization = (this.MaterialGradeT2[i].partFinishWeight / this.MaterialGradeT2[i].partGrossWeight).toFixed(2);
            this.MaterialGradeT2[i].directMaterialRate = parseFloat(this.MaterialGradeT2[i].directMaterialRate) / ((1 + 0.05) * 1 - ((1 - parseFloat(Utilization)) * (0.9)));

            if (isNaN(this.MaterialGradeT2[i].directMaterialRate)) {
              this.MaterialGradeT2[i].directMaterialRate = null;
            }
            break;
          }

        }
      }

      this.findsum(data.shouldCostBreakdown, data.shouldCostBreakdownNon);

      this.findsumT2(data.shouldCostBreakdownT2, data.shouldCostBreakdownNonT2);

      this.imgsilderData = data.imgsilderDatas;

      debugger;;
      if (this.imgsilderData.length <= 0) {
        this.mainimg = localStorage.getItem("imagePath");
      }
      else {
        this.mainimg = this.imgsilderData[0];
        console.log('mainimg', data.imgsilderDatas);
        this.fvOnly = data.imgsilderDatas.map((item: string) => item.split('\\').pop());
        this.imgName = this.fvOnly.map((item: string) => item.split('.')[0]);

        localStorage.setItem("imagePath", this.mainimg);


      }


      localStorage.setItem("DebriefDateFormated", this.DebriefDateFormated)
      localStorage.setItem("ForexRegion", this.ForexRegion)
      var ProjectName = this.Projecttype + '-' + this.BusinessUnit + '-' + this.ProjectName + '-' + this.Location + '-' + this.PartName + '-' + this.PartNumber;
      localStorage.setItem("ProjectName", ProjectName);

      this.SpinnerService.hide('spinner');
    }
    catch (e) {
      this.SpinnerService.hide('spinner');
    }
  }

  ChekNull(v: any): any {
    if (v == null || v == undefined || v <= 0) {
      return this.NA;
    }
    else {
      return v;
    }
  }

  ChekNull_LWH(v: any): any {
    if (v == null || v == undefined) {
      return this.NA;
    }
    else {
      return v + " mm ";
    }
  }

  ChekNull_Wt(): any {
    if (this.PartWeight == null || this.PartWeight == 0 || this.PartWeight == undefined || this.PartWeight == 'NA*' || this.PartWeight_in_Pounds == 0 || this.PartWeight_in_Pounds == null || this.PartWeight_in_Pounds === undefined || this.PartWeight_in_Pounds == 'NA*') {
      return this.NA;
    }
    else {
      return this.PartWeight + ' kg' + ' / ' + this.PartWeight_in_Pounds + ' lbs';
    }
  }


  findsum(data: any, data2: any) {

    for (let i = 0; i < data.length; i++) {
      this.Manu_TotalInUSD += data[i].usdValue;
      this.Manu_TotalInLocal += data[i].localValue;
    }

    for (let i = 0; i < data2.length; i++) {
      this.Non_TotalInUSD += data2[i].usdValue;
      this.Non_TotalInLocal += data2[i].localValue;
    }

    this.TotalInUSD = this.Manu_TotalInUSD + this.Non_TotalInUSD;
    this.TotalInLocal = this.Manu_TotalInLocal + this.Non_TotalInLocal;

    //debugger;
    for (let i = 0; i < data.length; i++) {
      this.shouldCostBreakdownList[i].totalCostPer = data[i].usdValue / this.TotalInUSD * 100;
    }

    //debugger;;
    for (let i = 0; i < this.shouldCostBreakdownNonList.length; i++) {
      this.shouldCostBreakdownNonList[i].totalCostPer = data2[i].usdValue / this.TotalInUSD * 100;
    }

    for (let i = 0; i < this.shouldCostBreakdownList.length; i++) {
      this.Manu_TotalInPer += this.shouldCostBreakdownList[i].totalCostPer;
    }

    for (let i = 0; i < this.shouldCostBreakdownNonList.length; i++) {
      this.Non_TotalInPer += this.shouldCostBreakdownNonList[i].totalCostPer;
    }

    this.TotalInPer = Number(this.Manu_TotalInPer) + Number(this.Non_TotalInPer);
  }



  findsumT2(data: any, data2: any) {

    for (let i = 0; i < data.length; i++) {
      this.Manu_TotalInUSDT2 += data[i].usdValue;
      this.Manu_TotalInLocalT2 += data[i].localValue;
    }

    for (let i = 0; i < data2.length; i++) {
      this.Non_TotalInUSDT2 += data2[i].usdValue;
      this.Non_TotalInLocalT2 += data2[i].localValue;
    }

    this.TotalInUSDT2 = this.Manu_TotalInUSDT2 + this.Non_TotalInUSDT2;
    this.TotalInLocalT2 = this.Manu_TotalInLocalT2 + this.Non_TotalInLocalT2;

    for (let i = 0; i < data.length; i++) {
      this.shouldCostBreakdownListT2[i].totalCostPer = data[i].usdValue / this.TotalInUSDT2 * 100;
    }

    for (let i = 0; i < this.shouldCostBreakdownNonListT2.length; i++) {
      this.shouldCostBreakdownNonListT2[i].totalCostPer = data2[i].usdValue / this.TotalInUSDT2 * 100;
    }

    for (let i = 0; i < this.shouldCostBreakdownListT2.length; i++) {
      this.Manu_TotalInPerT2 += this.shouldCostBreakdownListT2[i].totalCostPer;
    }

    for (let i = 0; i < this.shouldCostBreakdownNonListT2.length; i++) {
      this.Non_TotalInPerT2 += this.shouldCostBreakdownNonListT2[i].totalCostPer;
    }

    this.TotalInPerT2 = Number(this.Manu_TotalInPerT2) + Number(this.Non_TotalInPerT2);
  }

  showdata(e: any) {
    const myElement1 = document.getElementById("ProjectDetails");
    const myElement2 = document.getElementById("ShouldCostBreakdown");
    const myElement3 = document.getElementById("MaterialGradeDetails");
    const myElement4 = document.getElementById("PartDimensionDetails");
    const myElement5 = document.getElementById("CostModelerDetails");

    myElement1?.classList.remove("showblock");
    myElement2?.classList.remove("showblock");
    myElement3?.classList.remove("showblock");
    myElement4?.classList.remove("showblock");
    myElement5?.classList.remove("showblock");

    myElement1?.classList.add("hideblock");
    myElement2?.classList.add("hideblock");
    myElement3?.classList.add("hideblock");
    myElement4?.classList.add("hideblock");
    myElement5?.classList.add("hideblock");


    const btn1 = document.getElementById("btnProjectDetails");
    const btn2 = document.getElementById("btnShouldCostBreakdown");
    const btn3 = document.getElementById("btnMaterialGradeDetails");
    const btn4 = document.getElementById("btnPartDimensionDetails");
    const btn5 = document.getElementById("btnCostModelerDetails");
    btn1?.classList.remove("active");
    btn2?.classList.remove("active");
    btn3?.classList.remove("active");
    btn4?.classList.remove("active");
    btn5?.classList.remove("active");


    switch (e) {
      case 1: {
        myElement1?.classList.add("showblock");
        btn1?.classList.add("active");
        break;
      }
      case 2: {
        myElement2?.classList.add("showblock");
        btn2?.classList.add("active");
        break;
      }
      case 3: {
        myElement3?.classList.add("showblock");
        btn3?.classList.add("active");
        break;
      }
      case 4: {
        myElement4?.classList.add("showblock");
        btn4?.classList.add("active");
        break;
      }
      case 5: {
        myElement5?.classList.add("showblock");
        btn5?.classList.add("active");
        break;
      }
    }
  }

  UpdateReport() {
    this.router.navigate(['/home/tiercost']);
  }

  SendNewRequest() {
    this.router.navigate(['/home/shouldcostrequest', this.UniqueId]);
  }


  @ViewChild('printsection') printsection!: ElementRef;
  async DownloadReport() {

    this.toastr.success("Report downloading has started.");

    var id = this.UniqueId;
    var staticUrl = environment.apiUrl_Search + 'DownloadPDF?Id=' + id;

    var PartNo = '';
    var PartNm = '';

    if (this.PartNumber == null) {
      PartNo = '';
    }
    else {
      PartNo = this.PartNumber;
    }
    if (this.PartName == null) {
      PartNm = '';
    }
    else {
      PartNm = this.PartName;
    }

    var xhr = new XMLHttpRequest();
    xhr.open('GET', staticUrl, true);
    xhr.responseType = 'blob';
    xhr.onload = function (e) {
      if (this.status == 200) {
        var myBlob = this.response;
        var reader = new window.FileReader();
        reader.readAsDataURL(myBlob);
        reader.onloadend = function () {
          const base64data = reader.result;

          var file = new Blob([myBlob], { type: 'application/zip' });
          var fileURL = URL.createObjectURL(file);

          var fileLink = document.createElement('a');
          fileLink.href = fileURL;


          fileLink.download = PartNo + ' ' + PartNm;
          //fileLink.download =  'dss';

          fileLink.click();
        }
      }
      else {
        alert("File Not Fount");
      }
    };
    xhr.send();

    // const download = await this.searchservice.downloadShouldeCost(this.ComapredId, this.userId).toPromise();

    // const pdf = new jsPDF('p', 'mm', 'a4');

    // const pages = document.querySelectorAll('.page');

    // for (const [index, page] of Array.from(pages).entries()) {
    //   const canvas = await html2canvas(page as HTMLElement, { scale: 3 });

    //   const paddingTop = 50;
    //   const paddingRight = 50;
    //   const paddingBottom = 50;
    //   const paddingLeft = 50;

    //   const canvasWidth = canvas.width + paddingLeft + paddingRight;
    //   const canvasHeight = canvas.height + paddingTop + paddingBottom;

    //   const newCanvas = document.createElement('canvas');
    //   newCanvas.width = canvasWidth;
    //   newCanvas.height = canvasHeight;
    //   const ctx = newCanvas.getContext('2d');

    //   if (ctx) {
    //     ctx.fillStyle = '#ffffff'; // Background color
    //     ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    //     ctx.drawImage(canvas, paddingLeft, paddingTop);
    //   }

    //   const imgData = newCanvas.toDataURL('image/JPEG');
    //   const imgProps = pdf.getImageProperties(imgData);
    //   const pdfWidth = pdf.internal.pageSize.getWidth();
    //   const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    //   pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);

    //   if (index < pages.length - 1) {
    //     pdf.addPage();
    //   }
    // }

    // // const currentDateAndTime = this.datePipe.transform(new Date(), 'yyyy-MM-dd HH:mm:ss');
    // var filename = "Should Cost Report.pdf";
    // pdf.save(filename);

  }

  setImg(e: any) {
    this.mainimg = e
  }

  ZoomImg(e: any) {

    if (e.currentTarget.currentSrc != "") {
      this.mainimgzoom = e.currentTarget.currentSrc;

      const zoomImg = document.getElementById("zoomImg");
      zoomImg?.classList.remove("zoomImghide");
      zoomImg?.classList.add("zoomImgshow");
    }

  }

  ZoomImgclose() {
    const zoomImg = document.getElementById("zoomImg");
    zoomImg?.classList.remove("zoomImgshow");
    zoomImg?.classList.add("zoomImghide");
    this.mainimgzoom = '';
  }

  ChekNull_ToolingCost(TC: any): any {
    if (TC == null || TC == undefined || TC <= 0) {
      return this.NA;
    }
    else {
      return '$' + this.ToolingCost
    }
  }

  backToPreviousPage() {
    this.location.back();
  }

}
