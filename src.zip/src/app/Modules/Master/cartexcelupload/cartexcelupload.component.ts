import { Component } from '@angular/core';

@Component({
  selector: 'app-cartexcelupload',
  standalone: true,
  imports: [],
  templateUrl: './cartexcelupload.component.html',
  styleUrl: './cartexcelupload.component.css'
})
export class CartexceluploadComponent {

}
