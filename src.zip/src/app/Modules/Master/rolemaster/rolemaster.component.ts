
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { RoleUnitMaster } from 'src/app/Model/role-unit-master';
import { AdminService } from 'src/app/SharedServices/admin.service';
import { MasterServiceService } from 'src/app/SharedServices/master-service.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-rolemaster',
  templateUrl: './rolemaster.component.html',
  styleUrls: ['./rolemaster.component.css']
})
export class RolemasterComponent implements OnInit {

  constructor(public router: Router,
    private masterService: MasterServiceService,
    private toastr: ToastrService, private location: Location) {
    this.config = {
      currentPage: 1,
      itemsPerPage: 10
    };
  }


  page: number = 1;
  pageSize: number = 10;
  config: any;
  filterMetadata = { count: 0 };

  rollMasterForm!: FormGroup
  roleUnitMaster: RoleUnitMaster[] = [];
  getMenu: any = {};
  getRole: any = {};

  display = "none";
  header: string = '';
  txt_btn: string = '';
  roleName: any;
  RoleId: any;
  menu: any = {};
  description: any;
  status: any;
  date: Date = new Date();
  editModal: boolean = false;
  editRowIndex: number = 0;
  textsearch: string = '';
  dataArr: any = {};

  showError1: boolean = false;
  showError2: boolean = false;
  showError3: boolean = false;
  dropdownButton: any
  dropdownMenu: any
  list: any[] = []
  items: any[] = []
  selectedItems: any[] = []
  checkedList: any[] = []
  menuList: any[] = []
  currentSelected: {} = {}
  roleData: any = {};
  showDropDown: boolean = false
  // shareIndividualCheckedList :{}={}
  // shareCheckedList :any[]=[]


  ngOnInit(): void {

    if (localStorage.getItem("userName") == null) {
      this.router.navigate(['/welcome']);
      return;
    }


    const dropdownButton = document.getElementById('multiSelectDropdown');
    const dropdownMenu = document.querySelector('.dropdown-menu');

    this.rollMasterForm = new FormGroup({
      textsearch: new FormControl(),

    });
    this.getRoleData();
    //console.log('menu list', this.getMenuList())

    const chBoxes = document.querySelectorAll('.dropdown-menu input[type="checkbox"]');
    const dpBtn = document.getElementById('multiSelectDropdown');

    let mySelectedListItems = [];
  }

  onCheckboxChange(item: any): void {
    if (item.checked) {
      // Add the selected item to the selectedItems array
      this.selectedItems.push(item);
      //console.log(this.selectedItems)
    } else {
      // Remove the item from the selectedItems array
      this.selectedItems = this.selectedItems.filter(selectedItem => selectedItem.id !== item.id);

    }

  }

  openModal() {
    this.display = "block";
    if (this.editModal) {
      this.header = 'Edit Data';
      this.txt_btn = 'Update';
      this.roleName = this.getRole[this.editRowIndex].RoleName;
      this.RoleId = this.getRole[this.editRowIndex].RoleId;
      this.description = this.getRole[this.editRowIndex].Description;
      this.status = this.getRole[this.editRowIndex].status;
      // console.log('edit array', this.menu, this.getRole[this.editRowIndex].MenuId)

    } else {
      this.getMenuList();
      this.header = 'Add Data';
      this.txt_btn = 'Save';
      this.roleName = "";
      this.menu = this.getMenu;
      this.description = "";
      this.status = "";
      this.checkedList = [];
      this.menuList = [];

    }
  };


  async getMenuList() {
    const data = await this.masterService.getMenuList().toPromise();
    this.getMenu = data;

    this.updatelist = this.getMenu.map((d: any) => ({ ...d, checked: false }));
    //console.log('menu', this.updatelist)


  }
  getRoleData() {
    this.masterService.getRole().subscribe(_result => {
      this.getRole = _result;
      // console.log('ssssss', this.getRole)
    })
  }

  deleteRow(rowIndex: any) {

    if (confirm("Are you sure you want to delete Role?")) {

      this.dataArr = {
        RoleId: rowIndex,
        ModifiedBy: Number(localStorage.getItem("userId"))
      };
      this.masterService.deleteRole(this.dataArr).subscribe({
        next: (_res) => {

          this.toastr.success("Data Deleted Successfully.");
          this.getRoleData();
        },
        error: (error) => {
          console.error('API call error:', error);
        },
      });
    }
  }
  
  onCloseHandled() {
    this.display = "none";
    this.editModal = false;

  }
  onroleSelected(event: any) {
    this.roleName = event.target.value;
  }
  onItemChange(item: { text: string, selected: boolean }): void {
    // this.menu = event.target.value;

    if (item.selected) {
      this.checkedList.push(item.text);
    } else {

      const index = this.checkedList.indexOf(item.text)
      if (index !== -1) {
        this.checkedList.splice(index, 1)
      }

    }

  }

  descriOnBlur(event: any) {
    this.description = event.target.value;
  }
  roleOnBlur(event: any) {
    this.roleName = event?.target.value;
  }
  onSelected(event: any) {
    this.status = event.target.value;
  }

  updatelist: any;

  async editModalMethod(rowIndex: any, item: any) {

    const data = await this.masterService.getMenuList().toPromise();
    this.updatelist = data;
    if (this.updatelist.length > 0) {
      this.menuList = [];
      this.editModal = true;
      //this.Reset_List();
      this.editRowIndex = rowIndex;
      this.openModal();
      let Menu = item.MenuId.split(',');
      this.checkedList = [];
      Menu.forEach((element: any) => {
        this.checkedList.push(Number(element));
      });
      for (let i = 0; i < this.checkedList.length; i++) {

        for (let j = 0; j < this.updatelist.length; j++) {
          if (this.checkedList[i] === this.updatelist[j].MenuId) {
            this.menuList.push(this.updatelist[j].Menu);
            this.updatelist[j].checked = true;
            break;
          }

        }
      }
      //console.log('my menu checked ', this.updatelist)
    }
  }

  onSaveButton() {
    if (!this.onClickBlankInputValidation()) {
      if (this.editModal) {
        // console.log('edit called array', this.getRole)
        this.getRole[this.editRowIndex].RoleId = this.RoleId
        this.getRole[this.editRowIndex].RoleName = this.roleName
        this.getRole[this.editRowIndex].Description = this.description
        //this.roleUnitMaster[this.editRowIndex].MenuId=this.list
        let list = this.checkedList.join(',')
        //console.log(this.checkedList)
        // console.log(list)
        this.roleData = {
          RoleId: this.RoleId,
          RoleName: this.roleName,
          Description: this.description,
          MenuId: list,
          ModifiedBy: Number(localStorage.getItem("userId"))
        }
        this.masterService.updateRole(this.roleData).subscribe(
          response => {
            //console.log('Record updated successfully:', response);
            this.getRoleData();
            this.toastr.success("Data Updated Successfully.");
          },
          error => {
            console.error('Error inserting record:', error);

          }
        );

        // console.log('saved role data', this.roleData)
      }
      else {
        let list = this.checkedList.join(',')
        // console.log(list)
        this.dataArr = {
          RoleName: this.roleName,
          Description: this.description,
          MenuId: list,
          CreatedBy: Number(localStorage.getItem("userId"))
        };



        this.masterService.addRole(this.dataArr).subscribe(
          response => {
            // console.log('Record inserted successfully:', response);
            this.getRoleData();
            this.toastr.success("Data Inserted Successfully.");
          },
          error => {
            console.error('Error inserting record:', error);

          }
        );

      }
      this.editModal = false;
      this.display = "none";
    }
  }

  onClickBlankInputValidation(): boolean {
    if (this.roleName === '') {
      this.showError1 = true;
      return true;
    }
    else if (this.checkedList.length <= 0) {
      this.showError2 = true;
      return true;
    }
    else if (this.description === '') {
      this.showError3 = true;
      return true;
    }
    else {
      return false;
    }


  }


  getSelectedValue(status: Boolean, value: number, Menu: string) {
    if (status) {
      this.checkedList.push(value);
      this.menuList.push(Menu);
      // console.log('my list', this.menuList)
    } else {
      var index = this.checkedList.indexOf(value);
      this.checkedList.splice(index, 1);
      this.menuList.splice(index, 1);
    }

    this.currentSelected = { checked: status, name: value };
    // console.log('my list', this.currentSelected)

  }

  backToPreviousPage() {
    this.location.back();
  }

}
