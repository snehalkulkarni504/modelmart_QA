import { Component, ComponentFactoryResolver, ComponentRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { SearchService } from 'src/app/SharedServices/search.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-comparison',
  templateUrl: './comparison.component.html',
  styleUrls: ['./comparison.component.css']
})
export class ComparisonComponent implements OnInit {
 
  constructor(public searchservice: SearchService, public router: Router, private location: Location) { }

  compardata: any[] = [];
  compardataTier2 :any[]=[];
  colunms: any[] = [];
  headers: any[] = [];
  ids: any = [];
  data: any[] = [];
  test: any;
  NA: any = "NA*";

  shouldCostBreakdownList :any;
  shouldCostBreakdownNonList:any;

  Manu_TotalInUSD: number = 0;
  TotalInUSD: number = 0;

  ngOnInit(): void {
    if (localStorage.getItem("userName") == null) {
      this.router.navigate(['/welcome']);
      return;
    }

    this.ids = localStorage.getItem("ComapredcheckedboxIds");
    this.GetData();
    this.test = "te dgy djsd\n s dsdnjs";
  }


  getComparison(e: any) {
    //debugger;;
    localStorage.setItem("ComapredId", e);
    this.router.navigate(['/home/shouldcost']);
  }

  async GetData() {
    const data = await this.searchservice.getComparisonData(this.ids).toPromise();
    this.compardata = data;
    
  }

  ChekNull(v: any): any {
    if (v == null || v == undefined || v <= 0) {
      return this.NA;
    }
    else {
      return v;
    }
  }

  backToPreviousPage() {
    this.location.back();
  }

  // -------------- popup -------

  //elPopup: any;
  async showPopup(d: any, evt: any, key: any, row: any, getId: number) {
    //debugger;;
    this.compardataTier2 = [];

    let CSheaderId;
    switch (getId) {
      case 1: {
        CSheaderId = this.compardata[0].details1;
        break;
      }
      case 2: {
        CSheaderId = this.compardata[0].details2;
        break;
      } 
      case 3: {
        CSheaderId = this.compardata[0].details3;
        break;
      }
      case 4: {
        CSheaderId = this.compardata[0].details4;
        break;
      }
    }

    let val = parseFloat(row);
    if (d.id == 19 && key == 'data' && val > 0) {

      const data = await this.searchservice.getCompardataTier2(CSheaderId).toPromise();
      this.compardataTier2 = data;
      this.shouldCostBreakdownList = [];
      this.shouldCostBreakdownNonList = [];
      
      this.shouldCostBreakdownList = data.compardatashouldCostBreakdown;
      this.shouldCostBreakdownNonList = data.compardatashouldCostBreakdownNon;

      // Position:
      const absX = evt.clientX + window.scrollX;
      const absY = evt.clientY + window.scrollY;

      const element = document.getElementById('Tier2Pupop') as HTMLElement;
      element.style.left = absX + 'px';
      element.style.top = absY + 'px';
      element.style.visibility = 'visible';

      
      setTimeout(() => {
        this.findsum(data.compardatashouldCostBreakdown, data.compardatashouldCostBreakdownNon);
      }, 100);
      
    }
    else {
      const element = document.getElementById('Tier2Pupop') as HTMLElement;
      element.style.visibility = 'hidden';
    }
  }

  findsum(data: any, data2: any) {

    //debugger;;
    let Non_TotalInUSD  = 0 ;
    this.Manu_TotalInUSD = 0;
    this.TotalInUSD = 0;

    for (let i = 0; i < data.length; i++) {
      this.Manu_TotalInUSD += data[i].col2;
    }
    for (let i = 0; i < data2.length; i++) {
      Non_TotalInUSD += data2[i].col2;
    }

    this.TotalInUSD = this.Manu_TotalInUSD + Non_TotalInUSD;
  }

}

