export interface Engine {
    edId: any;
    EDId?: number,
    Value: string,
    Description: string,
    CreatedBy: string,
    CreatedOn: Date,
    IsActive:boolean,
    ModifiedBy:string,
    ModifiedOn:Date
}