export interface NodeService {

    
}


