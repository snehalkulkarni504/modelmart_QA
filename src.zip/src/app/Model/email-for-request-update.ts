export interface EmailForRequestUpdate {
    RequesterId?:number,
    Comments?:string,
    PreviousStatus?:string,
    Status?:string,
    RequestDate?:Date,
    RequesterName?:number,
}
