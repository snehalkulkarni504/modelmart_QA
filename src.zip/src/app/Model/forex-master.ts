export interface ForexMaster {
    ForexId: number,
    Location: string,
    Currency: string,
    Year:any,
    ForexValue:number,
    Status:string,
    CreatedBy: string,
    CreatedOn: Date
}
