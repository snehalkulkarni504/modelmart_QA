export interface MasterMaintenance {
    id: number,
    locationName: string,
    localCurrency: string,
    status:string,
    createdBy: string,
    createdDate: Date
}