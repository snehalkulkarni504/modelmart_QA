export class compareIds {
    M!: any[];   
    S!: any[];
}