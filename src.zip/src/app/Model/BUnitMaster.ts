export interface BUnitMaster {
    BUId?: number,
    Name?: string,
    SubUnit?: string,
    status?:string,
    CreatedBy?: string,
    CreatedOn?: Date,
    ModifiedBy?:string
    Description?:string,
    IsActive:any
}

