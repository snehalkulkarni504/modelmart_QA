export interface SearchFilters {
    cat2:any,
    cat3:any,
    cat4:any
}

export interface SearchFiltersCat4
{
  name: string 
}
 