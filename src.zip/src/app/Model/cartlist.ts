export interface Cartlist {
    chHeaderId:string,
    Uniqueid:string
}
