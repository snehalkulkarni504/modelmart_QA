export interface CategoryMaster{

    ParentCategory:string;
    ChildCategory:string;
    GroupCategory:string;
    CreatedBy:string;

}