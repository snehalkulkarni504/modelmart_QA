export interface UpdateSendRequest {
    requestHeaderID?: number,
    projectType?: string,
    businessUnit?: string,
    programName?: string,
    materialGrade?: string,
    uniqueID?: string,
    ProjectName?: string
}