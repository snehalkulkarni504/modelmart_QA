import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MsalService } from '@azure/msal-angular';
import { AuthenticationResult } from '@azure/msal-browser';
 

@Component({
  selector: 'app-welcomepage',
  templateUrl: './welcomepage.component.html',
  styleUrls: ['./welcomepage.component.css']
})
export class WelcomepageComponent implements OnInit {

  isUserLoggedIn: boolean = false;
  myScriptElement: HTMLScriptElement;
  emailID: any = "test";

  loginDisplay = false;

  constructor(public router: Router,private msalService: MsalService) {
    this.myScriptElement = document.createElement("script");
    this.myScriptElement.src = "assets/slider.js";
    document.body.appendChild(this.myScriptElement);
  }

  //private msalBroadcastService: MsalBroadcastService,
  //@Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration

  // constructor(public router: Router
  // ) {
  //   this.myScriptElement = document.createElement("script");
  //   this.myScriptElement.src = "assets/slider.js";
  //   document.body.appendChild(this.myScriptElement);
  // }



  ngOnInit(): void {
  }


  GotoLogin() {
    this.router.navigate(['/login']);
  }

  async loginRedirect() {
  //  debugger;
    // if (this.msalGuardConfig.authRequest) {
    //   this.msalService.loginRedirect({ ...this.msalGuardConfig.authRequest } as RedirectRequest);
    // } else {
    //   this.msalService.loginRedirect();
    // }


    this.msalService.loginPopup().subscribe((response: AuthenticationResult) => {
      if (response != null) {
        this.emailID = response.account?.username!;
        var UserNm = this.emailID.slice(0, this.emailID.indexOf("@"));
        localStorage.setItem('userName', UserNm);
        if (UserNm.length > 0) {
          this.router.navigate(['/home/search/ ']);
        }
      }
    });



  }


}
