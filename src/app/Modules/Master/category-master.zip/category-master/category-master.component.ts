import { Component, OnInit, Renderer2 } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { MasterServiceService } from 'src/app/SharedServices/master-service.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-category-master',
  templateUrl: './category-master.component.html',
  styleUrls: ['./category-master.component.css']
})
export class CategoryMasterComponent implements OnInit {

  CategoryxMasterForm !: FormGroup;
  CategoryTree: any = [];
  textsearch: string = '';
  filterMetadata = { count: 0 };
  

  constructor(public router: Router,
    private masterService: MasterServiceService,
    private toastr: ToastrService,
    private location: Location,
    private renderer: Renderer2,
    private SpinnerService: NgxSpinnerService) {

  }

  ngOnInit() {

    if (localStorage.getItem("userName") == null) {
      this.router.navigate(['/welcome']);
      return;
    }

    this.CategoryxMasterForm = new FormGroup({
      textsearch: new FormControl(),
    });

    this.getCategoryTree();

  }


  getCategoryTree() {
    this.CategoryTree = [];
    this.SpinnerService.show('spinner');

    this.masterService.getCategoryTree().subscribe({
      next: (res: any) => {
        this.CategoryTree = res;
      },
      error: (error: any) => {
        console.error('Inserting API call error:', error);
      },
    });

  }


  backToPreviousPage() {
    this.location.back();
  }


}
